import requests

url = "http://127.0.0.1:11434/api/generate"

payload = {
    "model": "gemma3:1b",
    "prompt": "Say hello in English, Hindi, Bengali, Marathi, and Punjabi.",
    "stream": False
}

response = requests.post(url, json=payload, timeout=180)
response.raise_for_status()

result = response.json()
print("Model response:")
print(result["response"])
