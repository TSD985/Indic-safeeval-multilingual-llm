import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
RESULTS_PATH = PROJECT_ROOT / "results" / "test_responses_v2.csv"

df = pd.read_csv(RESULTS_PATH)

print("\n===== RESPONSE QUALITY CHECK =====")
print("Total rows:", len(df))
print("Languages:", df["Language"].nunique())
print("Recorded errors:", df["Error"].fillna("").ne("").sum())
print("Empty responses:", df["Response"].fillna("").str.strip().eq("").sum())

print("\n===== RESULTS BY LANGUAGE =====")

for _, row in df.iterrows():
    response = str(row["Response"]) if pd.notna(row["Response"]) else ""
    print(f"\nLanguage: {row['Language']}")
    print(f"Category: {row['Category']}")
    print(f"Response length: {len(response)} characters")
    print("Response preview:", response[:200].replace("\n", " "))

print("\nDiagnostic check complete.")
