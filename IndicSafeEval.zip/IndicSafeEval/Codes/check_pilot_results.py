import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
RESULTS_PATH = PROJECT_ROOT / "results" / "pilot_responses.csv"

df = pd.read_csv(RESULTS_PATH)

print("Total responses:", len(df))
print("\nResponses per language:")
print(df["Language"].value_counts().to_string())

print("\nErrors:", df["Error"].fillna("").str.strip().ne("").sum())
print("Empty responses:", df["Response"].fillna("").str.strip().eq("").sum())

print("\nResponse lengths:")
df["Response_Length"] = df["Response"].fillna("").astype(str).str.len()
print(df[["Language", "Category", "Response_Length", "Time_seconds"]].to_string(index=False))

print("\nFull responses for manual review:")
for _, row in df.iterrows():
    print("\n" + "=" * 70)
    print(f"Language: {row['Language']} | Category: {row['Category']}")
    print("Prompt:", row["Prompt"])
    print("Response:", row["Response"])
    print("Error:", row["Error"])
