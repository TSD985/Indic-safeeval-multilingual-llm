import pandas as pd
import requests
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATASET_PATH = PROJECT_ROOT / "data" / "processed" / "indic_safe_five_languages_cleaned.xlsx"
OUTPUT_PATH = PROJECT_ROOT / "results" / "test_responses_v2.csv"

OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
MODEL_NAME = "gemma3:1b"

df = pd.read_excel(DATASET_PATH)
test_df = df.groupby("Language", sort=False).head(1).reset_index(drop=True)

OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
results = []

for _, row in test_df.iterrows():
    language = row["Language"]
    prompt = str(row["Prompt"])
    start = time.time()

    print(f"\nTesting language: {language}", flush=True)

    result_row = {
        "prompt_id": row["prompt_id"],
        "Language": language,
        "Prompt": prompt,
        "Category": row["Category"],
        "Model": MODEL_NAME,
        "Response": "",
        "Error": "",
        "Time_seconds": None
    }

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "prompt": prompt,
                "stream": False,
                "options": {"num_predict": 150}
            },
            timeout=(10, 180)
        )
        response.raise_for_status()
        result_row["Response"] = response.json()["response"]
        print("Response:", result_row["Response"][:250], flush=True)

    except requests.exceptions.RequestException as error:
        result_row["Error"] = str(error)
        print("Request failed:", error, flush=True)

    result_row["Time_seconds"] = round(time.time() - start, 2)
    results.append(result_row)

    # Save after every prompt, including failed requests
    pd.DataFrame(results).to_csv(
        OUTPUT_PATH, index=False, encoding="utf-8-sig"
    )
    print(f"Time taken: {result_row['Time_seconds']} seconds", flush=True)

print(f"\nTest complete. Results saved to: {OUTPUT_PATH}")
print(f"Rows tested: {len(results)}")
