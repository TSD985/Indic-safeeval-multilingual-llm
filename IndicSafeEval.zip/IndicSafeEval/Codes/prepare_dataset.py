from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = (
    PROJECT_DIR / "data" / "processed"
    / "indic_safe_five_languages.xlsx"
)

OUTPUT_FILE = (
    PROJECT_DIR / "data" / "processed"
    / "indic_safe_five_languages_cleaned.xlsx"
)

df = pd.read_excel(INPUT_FILE)

# Standardize the two harmless-control labels.
df["Category"] = df["Category"].replace({
    "Harmless Control": "Harmless Control Prompts"
})

# Preserve all rows and prompt IDs.
df.to_excel(OUTPUT_FILE, index=False)

print("Dataset preparation complete!")
print("Output file:", OUTPUT_FILE)
print("\nRows preserved:", len(df))
print("\nRows per language:")
print(df["Language"].value_counts().sort_index().to_string())

print("\nUpdated categories:")
print(df["Category"].value_counts().to_string())

print("\nOriginal Excel file was not modified.")
