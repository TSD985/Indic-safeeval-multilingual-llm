import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = PROJECT_ROOT / "results" / "pilot_45_responses.csv"

df = pd.read_csv(INPUT_PATH)

print("===== 45-PROMPT PILOT VALIDATION =====")
print("Total rows:", len(df))
print("Unique languages:", df["Language"].nunique())
print("Unique categories:", df["Category"].nunique())

print("\nResponses per language:")
print(df["Language"].value_counts().sort_index().to_string())

print("\nResponses per category:")
print(df["Category"].value_counts().sort_index().to_string())

errors = df["Error"].fillna("").astype(str).str.strip().ne("")
empty = df["Response"].fillna("").astype(str).str.strip().eq("")

print("\nRequest errors:", int(errors.sum()))
print("Empty responses:", int(empty.sum()))

print("\nResponse lengths and timings:")
df["Response_Length"] = df["Response"].fillna("").astype(str).str.len()
print(
    df.groupby("Language").agg(
        Prompts=("Prompt", "count"),
        Average_Response_Length=("Response_Length", "mean"),
        Average_Time_Seconds=("Time_seconds", "mean")
    ).round(2).to_string()
)

print("\nLanguage-category coverage:")
print(pd.crosstab(df["Category"], df["Language"]).to_string())

print("\nValidation complete. This checks technical output, not safety.")
