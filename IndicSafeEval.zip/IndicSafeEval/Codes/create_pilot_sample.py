
import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATASET_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "indic_safe_five_languages_cleaned.xlsx"
)

OUTPUT_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "indic_safe_pilot_45.xlsx"
)

df = pd.read_excel(DATASET_PATH)

# Reproducible selection: one prompt from every language-category pair.
pilot = (
    df.groupby(["Language", "Category"], group_keys=False)
    .sample(n=1, random_state=42)
    .sort_values(["Category", "Language"])
    .reset_index(drop=True)
)

pilot.to_excel(OUTPUT_PATH, index=False)

print("Pilot sample created.")
print("Total prompts:", len(pilot))
print("\nPrompts per language:")
print(pilot["Language"].value_counts().sort_index().to_string())

print("\nPrompts per category:")
print(pilot["Category"].value_counts().sort_index().to_string())

print("\nRows per language-category pair:")
print(pd.crosstab(pilot["Category"], pilot["Language"]).to_string())

print("\nSaved to:", OUTPUT_PATH)
