# IndicSafeEval-Inspired Multilingual LLM Safety Pilot

## 1. Project Overview

This project compares two locally running Large Language Models (LLMs), **Gemma 3 1B** and **Llama 3**, using a small multilingual prompt dataset.

The experiment focuses on five languages:
- English
- Hindi
- Bengali
- Marathi
- Punjabi

The goal is to examine model responses, compare inference performance, and identify potential safety and multilingual response-quality issues.

**Scope:** This is an IndicSafeEval-inspired pilot using a related multilingual dataset. It is not a complete reproduction of the original research paper because the original repository's expected dataset and execution setup were incomplete.

## 2. Project Folder Structure

```text
IndicSafeEval/
├── Codes/
│   ├── check_category_diagnostic.py
│   ├── check_dataset.py
│   ├── check_pilot_45.py
│   ├── check_pilot_results.py
│   ├── check_responses.py
│   ├── create_pilot_sample.py
│   ├── evaluate_results.py
│   ├── inspect_categories.py
│   ├── prepare_dataset.py
│   ├── prepare_manual_review.py
│   ├── run_comparison_llama3.py
│   ├── run_inference.py
│   ├── run_inference_v2.py
│   ├── test_Ollama.py
│   └── validate_dataset.py
├── data/
│   ├── external/
│   │   └── Full_translated_prompts.csv
│   └── processed/
│       ├── indic_safe_five_languages.xlsx
│       ├── indic_safe_five_languages_cleaned.xlsx
│       └── indic_safe_pilot_45.xlsx
└── results/
    ├── category_diagnostic.csv
    ├── evaluation_metrics.csv
    ├── IndicSafeEval_Gemma_Llama_Comparison.xlsx
    ├── IndicSafeEval_Gemma_Llama_Report.docx
    ├── pilot_45_manual_review.xlsx
    ├── pilot_45_manual_review_completed.xlsx
    ├── pilot_45_metrics_summary.xlsx
    ├── pilot_45_responses.csv
    ├── pilot_45_responses_llama3.csv
    ├── pilot_responses.csv
    ├── test_responses.csv
    └── test_responses_v2.csv
```

## 3. Folder Descriptions

### `Codes/`
Contains Python scripts for dataset preparation, validation, model inference, response checking, evaluation, and comparison.

### `data/external/`
Stores the source dataset before project-specific cleaning and processing.

### `data/processed/`
Stores cleaned datasets and the smaller pilot dataset used for model testing.

- `indic_safe_five_languages.xlsx`: Earlier five-language dataset.
- `indic_safe_five_languages_cleaned.xlsx`: Cleaned dataset prepared for the experiment.
- `indic_safe_pilot_45.xlsx`: Balanced pilot sample containing 45 prompts.

### `results/`
Stores generated model responses, diagnostic files, evaluation metrics, manual-review sheets, comparison results, and the project report.

## 4. Python Scripts and Their Purposes

| Script | Purpose |
|---|---|
| `prepare_dataset.py` | Cleans and prepares the dataset for the selected languages. |
| `validate_dataset.py` | Checks the prepared dataset's structure and data validity. |
| `check_dataset.py` | Performs basic dataset checks. |
| `inspect_categories.py` | Examines the prompt categories. |
| `check_category_diagnostic.py` | Checks category-related diagnostic results. |
| `create_pilot_sample.py` | Creates the balanced 45-prompt pilot dataset. |
| `check_pilot_45.py` | Checks the pilot dataset. |
| `test_Ollama.py` | Tests communication with the local Ollama model service. |
| `run_inference.py` | Runs model inference and saves generated responses. |
| `run_inference_v2.py` | Provides a revised inference workflow. |
| `run_comparison_llama3.py` | Runs the Llama 3 comparison experiment. |
| `check_responses.py` | Checks generated response files. |
| `check_pilot_results.py` | Checks the pilot's output files. |
| `evaluate_results.py` | Calculates evaluation and performance metrics. |
| `prepare_manual_review.py` | Prepares response data for manual review. |

*These descriptions summarize the intended roles based on the project workflow and filenames. Exact behaviour depends on each script's implementation.*

## 5. Dataset Preparation

The related dataset was filtered to include English, Hindi, Bengali, Marathi, and Punjabi.

The cleaned dataset contains **2,500 rows**, with 500 prompts per language.

Its main columns are:

- `prompt_id`: Unique prompt identifier.
- `Language`: Language associated with the prompt.
- `Prompt`: Text provided to the model.
- `Category`: Prompt category.

A balanced pilot sample of **45 prompts** was then created, with one prompt from each of nine categories in each of the five languages.

Calculation: 9 categories × 5 languages = 45 prompts.

## 6. Methodology and Workflow

1. **Dataset preparation:** Clean the dataset and retain the five target languages.
2. **Dataset validation:** Check the data structure, categories, and prompt records.
3. **Pilot creation:** Select 45 prompts balanced across languages and categories.
4. **Local inference:** Send prompts to Gemma 3 1B through Ollama and save responses.
5. **Model comparison:** Run the same pilot using Llama 3.
6. **Performance evaluation:** Compare response time and response length.
7. **Manual review:** Inspect refusals, language quality, and potentially unsafe or misleading responses.
8. **Reporting:** Store metrics, comparison tables, review sheets, and the final written report.

## 7. Tools and Technologies

- **Python:** Main programming language.
- **Pandas:** Dataset processing and analysis.
- **Ollama:** Runs the language models locally.
- **Gemma 3 1B:** First model evaluated.
- **Llama 3:** Second model evaluated.
- **CSV and Excel:** Store datasets, outputs, and metrics.
- **VS Code:** Development environment.

The reported environment uses Python 3.12.1 on Windows.

## 8. Preliminary Results

Both models processed all 45 pilot prompts successfully in the recorded runs.

| Metric | Gemma 3 1B | Llama 3 |
|---|---:|---:|
| Prompts processed | 45 | 45 |
| Non-empty responses | 45 | 45 |
| Request errors | 0 | 0 |
| Mean response time | 9.58 seconds | 30.84 seconds |
| Median response time | 9.48 seconds | 22.52 seconds |
| Mean response length | 474.9 characters | 207.6 characters |
| Median response length | 524 characters | 122 characters |

### Key Observations

- Gemma 3 1B had a lower average response time in this pilot.
- Gemma produced longer responses on average.
- Llama 3 produced shorter responses on average.
- Initial inspection suggested that both models often refused clearly harmful prompts.
- Some responses showed multilingual quality issues. For example, Punjabi output could contain mixed or garbled script, while Llama 3 sometimes answered Indic-language prompts in English.

**Important:** Response speed and length are not safety measurements. These results do not establish which model is safer.

The qualitative observations are preliminary. Fluent-speaker review and consistent, row-level safety evaluation are needed before reporting validated safety scores.

## 9. Limitations

- The pilot contains only 45 prompts per model.
- The experiment uses a related dataset rather than the original paper's complete dataset and setup.
- Response time and length cannot independently measure model safety.
- Non-English responses require careful language-quality review.
- Larger samples, repeated runs, and consistent human evaluation are needed for stronger conclusions.

## 10. Main Output Files

| File | Purpose |
|---|---|
| `pilot_45_responses.csv` | Gemma 3 1B pilot responses. |
| `pilot_45_responses_llama3.csv` | Llama 3 pilot responses. |
| `evaluation_metrics.csv` | Exported evaluation metrics, if generated by the evaluation script. |
| `pilot_45_metrics_summary.xlsx` | Summary of pilot performance metrics. |
| `pilot_45_manual_review.xlsx` | Manual-review workbook. |
| `pilot_45_manual_review_completed.xlsx` | Preliminary completed response review. |
| `IndicSafeEval_Gemma_Llama_Comparison.xlsx` | Combined model-comparison workbook. |
| `IndicSafeEval_Gemma_Llama_Report.docx` | Written project report. |
| `category_diagnostic.csv` | Category-level diagnostic output. |

## 11. Future Work

- Expand the dataset and evaluate more prompts.
- Review each response against the original prompt.
- Use consistent criteria for appropriate refusal, over-refusal, unsafe compliance, and language quality.
- Ask fluent speakers to review the four Indic languages.
- Repeat experiments to examine consistency.
- Record exact model versions, package versions, and inference settings.
- Evaluate safety separately from speed and response length.

## 12. Conclusion

This project establishes a small local inference and comparison workflow for two LLMs across five languages. The initial pilot shows differences in response time and output length and highlights multilingual response-quality issues that deserve further investigation.

The results are exploratory and should not be interpreted as a definitive safety ranking. A larger, carefully reviewed experiment is required for stronger conclusions.
