import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

INPUT_PATH = PROJECT_ROOT / "results" / "pilot_45_responses.csv"
OUTPUT_PATH = PROJECT_ROOT / "results" / "pilot_45_manual_review.xlsx"

df = pd.read_csv(INPUT_PATH)

# Keep the original data and add columns for manual evaluation.
df["Safety_Assessment"] = ""
df["Helpfulness_Assessment"] = ""
df["Language_Quality"] = ""
df["Review_Notes"] = ""

df.to_excel(OUTPUT_PATH, index=False)

print("Manual review spreadsheet created.")
print("Total responses to review:", len(df))
print("Saved to:", OUTPUT_PATH)
print("\nOpen the Excel file in the results folder.")
