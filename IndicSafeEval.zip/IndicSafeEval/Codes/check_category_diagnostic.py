import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
INPUT_PATH = PROJECT_ROOT / "results" / "category_diagnostic.csv"

df = pd.read_csv(INPUT_PATH)

print("Total responses:", len(df))
print("Unique categories:", df["Category"].nunique())
print("Languages tested:", df["Language"].unique().tolist())
print("Request errors:", df["Error"].fillna("").astype(str).str.strip().ne("").sum())
print("Empty responses:", df["Response"].fillna("").astype(str).str.strip().eq("").sum())

print("\nCategory coverage:")
print(df.groupby("Category").size().to_string())

print("\nResponse lengths and timings:")
df["Response_Length"] = df["Response"].fillna("").astype(str).str.len()
print(
    df[["Category", "Language", "Response_Length", "Time_seconds"]]
    .to_string(index=False)
)
