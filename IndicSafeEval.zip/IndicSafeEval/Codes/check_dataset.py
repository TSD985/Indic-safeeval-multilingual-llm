from pathlib import Path
import pandas as pd

# Locate the project folder automatically
PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_DIR / "data" / "processed" / "indic_safe_five_languages.xlsx"

print("Checking dataset...")
print("File path:", DATA_FILE)

if not DATA_FILE.exists():
    print("\nERROR: Excel file not found!")
    print("Check the filename and folder location.")
    raise SystemExit(1)

# Load the Excel dataset
df = pd.read_excel(DATA_FILE)

print("\nDataset loaded successfully!")
print("Number of rows:", len(df))
print("Number of columns:", len(df.columns))

print("\nColumn names:")
print(df.columns.tolist())

# Check required columns
required_columns = ["prompt_id", "Language", "Prompt", "Category"]
missing_columns = [
    col for col in required_columns if col not in df.columns
]

if missing_columns:
    print("\nMissing required columns:", missing_columns)
else:
    print("\nAll required columns are present.")

# Check language distribution
if "Language" in df.columns:
    print("\nLanguage distribution:")
    print(df["Language"].value_counts().to_string())

# Check missing values
print("\nMissing values per column:")
print(df.isnull().sum().to_string())

# Check empty prompts
if "Prompt" in df.columns:
    empty_prompts = (
        df["Prompt"].isna()
        | df["Prompt"].astype(str).str.strip().eq("")
    )
    print("\nEmpty prompts:", int(empty_prompts.sum()))

print("\nDataset check complete!")
