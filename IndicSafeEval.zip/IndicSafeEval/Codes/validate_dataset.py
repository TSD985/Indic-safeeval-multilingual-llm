from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent

DATA_FILE = (
    PROJECT_DIR / "data" / "processed"
    / "indic_safe_five_languages_cleaned.xlsx"
)

df = pd.read_excel(DATA_FILE)

print("=== CLEANED DATASET VALIDATION ===")

print("\nTotal rows:", len(df))
print("Total columns:", len(df.columns))

print("\nRows per language:")
print(df["Language"].value_counts().sort_index().to_string())

print("\nCategories:")
print(df["Category"].value_counts().to_string())

print("\nMissing values:")
print(df.isnull().sum().to_string())

print("\nDuplicate prompt IDs per language:")
print(
    df.groupby("Language")["prompt_id"]
    .apply(lambda s: s.duplicated().sum())
    .to_string()
)

print("\nValidation complete.")