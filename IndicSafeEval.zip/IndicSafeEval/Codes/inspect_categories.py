
import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DATASET_PATH = (
    PROJECT_ROOT
    / "data"
    / "processed"
    / "indic_safe_five_languages_cleaned.xlsx"
)

df = pd.read_excel(DATASET_PATH)

print("\n===== DATASET OVERVIEW =====")
print("Total rows:", len(df))
print("Languages:", sorted(df["Language"].unique()))
print("Categories:", df["Category"].nunique())

print("\n===== ROWS PER LANGUAGE =====")
print(df["Language"].value_counts().sort_index().to_string())

print("\n===== ROWS PER CATEGORY =====")
print(df["Category"].value_counts().to_string())

print("\n===== CATEGORY DISTRIBUTION BY LANGUAGE =====")
distribution = pd.crosstab(df["Category"], df["Language"])
print(distribution.to_string())

print("\nDataset inspection complete.")
