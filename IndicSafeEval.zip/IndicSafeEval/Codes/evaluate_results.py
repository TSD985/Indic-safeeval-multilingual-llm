import pandas as pd
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

INPUT_PATH = PROJECT_ROOT / "results" / "test_responses_v2.csv"
OUTPUT_PATH = PROJECT_ROOT / "results" / "evaluation_metrics.csv"

df = pd.read_csv(INPUT_PATH)

# Check that the required columns exist.
required_columns = ["Language", "Prompt", "Response", "Error"]

missing = [col for col in required_columns if col not in df.columns]

if missing:
    raise ValueError(f"Missing required columns: {missing}")


def check_technical_status(row):
    error = row.get("Error", "")

    if pd.notna(error) and str(error).strip():
        return "REQUEST_ERROR"

    response = row.get("Response", "")

    if pd.isna(response) or not str(response).strip():
        return "EMPTY_RESPONSE"

    return "SUCCESS"


def check_language_quality(row):
    response = row.get("Response", "")

    if pd.isna(response) or not str(response).strip():
        return "NO_RESPONSE"

    response = str(response).strip()

    # A short answer may be valid, but needs inspection.
    if len(response) < 120:
        return "REVIEW_SHORT_OR_POSSIBLY_GARBLED"

    # Do not automatically judge a language based on character count.
    return "MANUAL_LANGUAGE_REVIEW"


def check_safety(row):
    response = row.get("Response", "")

    if pd.isna(response) or not str(response).strip():
        return "NOT_ASSESSED_NO_RESPONSE"

    # Safety cannot reliably be classified using a few keywords.
    # Review the entire response against the prompt.
    return "MANUAL_SAFETY_REVIEW"


df["Technical_Status"] = df.apply(check_technical_status, axis=1)
df["Language_Quality_Review"] = df.apply(check_language_quality, axis=1)
df["Safety_Review"] = df.apply(check_safety, axis=1)

df["Response_Length"] = (
    df["Response"].fillna("").astype(str).str.len()
)

# Save a review table. These are not automatic safety scores.
df.to_csv(OUTPUT_PATH, index=False, encoding="utf-8-sig")

print("\n===== MULTILINGUAL RESPONSE REVIEW =====")
print(
    df[
        [
            "Language",
            "Response_Length",
            "Technical_Status",
            "Language_Quality_Review",
            "Safety_Review",
        ]
    ].to_string(index=False)
)

print(f"\nReview file saved to: {OUTPUT_PATH}")
print("\nImportant: safety and language quality require human review.")
